CREATE DATABASE mybusinessdb;
USE mybusinessdb;

CREATE TABLE businesses (
    id INT AUTO_INCREMENT PRIMARY KEY,
    business_name VARCHAR(255) NOT NULL,
    hq_location VARCHAR(255) NOT NULL,
    business_details TEXT NOT NULL,
    username VARCHAR(255) NOT NULL,
    password VARCHAR(255) NOT NULL,
logo_path VARCHAR(255) DEFAULT NULL
);

CREATE TABLE superadmins (
    id INT AUTO_INCREMENT PRIMARY KEY,
    business_id INT NOT NULL,
    username VARCHAR(255) NOT NULL,
    password VARCHAR(255) NOT NULL,
    FOREIGN KEY (business_id) REFERENCES businesses(id)
);

CREATE TABLE users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    business_id INT NOT NULL,
    username VARCHAR(255) NOT NULL,
    password VARCHAR(255) NOT NULL,
    user_type ENUM('buyer', 'seller') NOT NULL,
    FOREIGN KEY (business_id) REFERENCES businesses(id)
);

CREATE TABLE buyers (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(255) NOT NULL,
    password VARCHAR(255) NOT NULL,
    email VARCHAR(255) NOT NULL,
    fullname VARCHAR(255) NOT NULL,
    location VARCHAR(255) NOT NULL,
    business_id INT
);

CREATE TABLE sellers (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(255) NOT NULL,
    password VARCHAR(255) NOT NULL,
    email VARCHAR(255) NOT NULL,
    fullname VARCHAR(255) NOT NULL,
    location VARCHAR(255) NOT NULL,
    business_id INT
);

CREATE TABLE listings (
    id INT AUTO_INCREMENT PRIMARY KEY,
    seller_id INT NOT NULL,
    listing_name VARCHAR(255) NOT NULL,
    listing_description TEXT NOT NULL,
    price DECIMAL(10, 2) NOT NULL,
    listing_date TIMESTAMP NOT NULL,
    FOREIGN KEY (seller_id) REFERENCES sellers(id)
);

CREATE TABLE purchases (
    id INT AUTO_INCREMENT PRIMARY KEY,
    buyer_id INT NOT NULL,
    listing_id INT NOT NULL,
    purchase_date TIMESTAMP NOT NULL,
    FOREIGN KEY (buyer_id) REFERENCES buyers(id),
    FOREIGN KEY (listing_id) REFERENCES listings(id)
);