<!DOCTYPE html>
<html>
<head>
    <link rel="stylesheet" type="text/css" href="stylesheet.css">
    <title>Add Listing</title>
</head>
<body>
    <?php include 'nav_bar.php'; ?>
    <div class="form-container">
        <h2>Add Listing</h2>
        <form action="add_listing_to_seller.php" method="post">
            <p>Listing Name: <input type="text" name="listing_name" required></p>
            <p>Listing Description: <textarea name="listing_description" required></textarea></p>
            <p>Listing Price: <input type="text" name="listing_price" required></p>
            <input type="submit" value="Create Listing">
        </form>
    </div>
</body>
</html>
