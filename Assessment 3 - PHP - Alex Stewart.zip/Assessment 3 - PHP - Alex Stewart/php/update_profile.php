<?php
session_start();

if (isset($_SESSION['username'])) {
    $username = $_SESSION['username'];
    $account_type = $_SESSION['user_type'];

    if (!empty($account_type)) {
        $conn = new mysqli("localhost", "root", "", "mybusinessdb");

        if ($conn->connect_error) {
            die("Connection failed: " . $conn->connect_error);
        }

        $table_name = "";
        $username_column = "username";

        if ($account_type === 'business') {
            $table_name = "businesses";
        } elseif ($account_type === 'buyer') {
            $table_name = "buyers";
        } elseif ($account_type === 'seller') {
            $table_name = "sellers";
        } elseif ($account_type === 'superadmin') {
            $table_name = "superadmins";
        }

        if (!empty($table_name)) {
            if ($_SERVER["REQUEST_METHOD"] == "POST") {
                $newUsername = $_POST['new_username'];
                $newEmail = $_POST['new_email'];
                $newFullname = $_POST['new_fullname'];

                $updateFields = array();
                $params = array();

                if (isset($newUsername)) {
                    $updateFields[] = "$username_column = ?";
                    $params[] = $newUsername;
                }

                if (isset($newEmail)) {
                    $updateFields[] = "email = ?";
                    $params[] = $newEmail;
                }

                if (isset($newFullname)) {
                    $updateFields[] = "fullname = ?";
                    $params[] = $newFullname;
                }

                if (!empty($updateFields)) {
                    $updateFieldsString = implode(", ", $updateFields);

                    $sql = "UPDATE $table_name SET $updateFieldsString WHERE $username_column = ?";
                    $params[] = $username;

                    $stmt = $conn->prepare($sql);

                    $paramTypes = str_repeat('s', count($params));
                    $stmt->bind_param($paramTypes, ...$params);

                    if ($stmt->execute()) {
                        $_SESSION['username'] = $newUsername;
                        header('Location: account_info.php');
                        exit;
                    } else {
                        echo "Error updating profile: " . $stmt->error;
                    }

                    $stmt->close();
                } else {
                    echo "No fields to update.";
                }
            }
        } else {
            echo "Invalid account type.";
        }

        $conn->close();
    } else {
        echo "Invalid account type.";
    }
} else {
    echo "You are not logged in. Please log in to update your account information.";
}
?>
