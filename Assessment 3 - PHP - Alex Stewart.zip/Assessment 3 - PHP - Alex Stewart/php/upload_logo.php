<?php
session_start();

if (isset($_SESSION['username']) && $_SESSION['user_type'] === 'superadmin') {
    $username = $_SESSION['username'];

    $conn = new mysqli("localhost", "root", "", "mybusinessdb");

    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    $superadmin_query = "SELECT business_id FROM superadmins WHERE username = '$username'";
    $superadmin_result = $conn->query($superadmin_query);

    if ($superadmin_result->num_rows == 1) {
        $superadmin_row = $superadmin_result->fetch_assoc();
        $business_id = $superadmin_row['business_id'];

        if (isset($_FILES['logo']) && $_FILES['logo']['error'] === 0) {
            $logo = $_FILES['logo']['name'];
            $logo_tmp = $_FILES['logo']['tmp_name'];
            $logo_path = 'logos/' . $logo;

            if (move_uploaded_file($logo_tmp, $logo_path)) {
                $update_query = "UPDATE businesses SET logo_path = '$logo_path' WHERE id = $business_id";

                if ($conn->query($update_query) === TRUE) {
                    header('Location: account_info.php');
                    exit;
                } else {
                    echo "Error updating business logo: " . $conn->error;
                }
            } else {
                echo "Failed to upload the logo.";
            }
        }
    } else {
        echo "Superadmin not found in the database.";
    }

    $conn->close();
} else {
    echo "You are not logged in as a superadmin. Please log in to perform this action.";
}
