<!DOCTYPE html>
<html>
<head>
    <link rel="stylesheet" type="text/css" href="stylesheet.css">
    <title>View All Buyers/Sellers</title>
    <style>
        body {
            font-family: Arial, sans-serif;
        }

        .form-container {
            max-width: 800px;
            margin: 0 auto;
            padding: 20px;
        }

        .grid-container {
            display: flex;
            justify-content: space-between;
            margin-top: 20px;
        }

        .grid-item {
            flex: 1;
            background-color: #f3f3f3;
            padding: 20px;
            margin: 10px;
            border: 1px solid #ccc;
            border-radius: 5px;
        }

        table {
            width: 100%;
            border-collapse: collapse;
        }

        table th, table td {
            border: 1px solid #ccc;
            padding: 10px;
            text-align: left;
        }

        h3 {
            margin: 0;
        }
    </style>
</head>
<body>
    <?php include 'nav_bar.php'; ?>
    <div class="form-container">
        <h2>View All Buyers and Sellers</h2>
        <?php
        $conn = new mysqli("localhost", "root", "", "mybusinessdb");

        if ($conn->connect_error) {
            die("Connection failed: " . $conn->connect_error);
        }
        $sql_buyers = "SELECT email, fullname, location, id FROM buyers WHERE business_id IS NULL";
        $result_buyers = $conn->query($sql_buyers);
        $sql_sellers = "SELECT email, fullname, location, id FROM sellers WHERE business_id IS NULL";
        $result_sellers = $conn->query($sql_sellers);

        if (($result_buyers && $result_buyers->num_rows > 0) || ($result_sellers && $result_sellers->num_rows > 0)) {
            echo "<div class='grid-container'>";

            if ($result_buyers->num_rows > 0) {
                echo "<div class='grid-item'>";
                echo "<h3>Buyers:</h3>";
                echo "<table>";
                echo "<tr><th>Email</th><th>Full Name</th><th>Location</th>";
                if (isset($_SESSION['user_type']) && $_SESSION['user_type'] == 'superadmin') {
                    echo "<th>Action</th>";
                }
                echo "</tr>";

                while ($row = $result_buyers->fetch_assoc()) {
                    echo "<tr>";
                    echo "<td>" . $row["email"] . "</td>";
                    echo "<td>" . $row["fullname"] . "</td>";
                    echo "<td>" . $row["location"] . "</td>";
                    if (isset($_SESSION['user_type']) && $_SESSION['user_type'] == 'superadmin') {
                        echo "<td><a href='add_to_business.php?user_id=" . $row["id"] . "&user_type=buyer'>Add to Business</a></td>";
                    }
                    echo "</tr>";
                }
                echo "</table>";
                echo "</div>";
            }
            if ($result_sellers->num_rows > 0) {
                echo "<div class 'grid-item'>";
                echo "<h3>Sellers:</h3>";
                echo "<table>";
                echo "<tr><th>Email</th><th>Full Name</th><th>Location</th>";
                if (isset($_SESSION['user_type']) && $_SESSION['user_type'] == 'superadmin') {
                    echo "<th>Action</th>";
                }
                echo "</tr>";

                while ($row = $result_sellers->fetch_assoc()) {
                    echo "<tr>";
                    echo "<td>" . $row["email"] . "</td>";
                    echo "<td>" . $row["fullname"] . "</td>";
                    echo "<td>" . $row["location"] . "</td>";
                    if (isset($_SESSION['user_type']) && $_SESSION['user_type'] == 'superadmin') {
                        echo "<td><a href='add_to_business.php?user_id=" . $row["id"] . "&user_type=seller'>Add to Business</a></td>";
                    }
                    echo "</tr>";
                }
                echo "</table>";
                echo "</div>";
            }

            echo "</div>";
        } else {
            echo "No buyers or sellers without an associated business found.";
        }
        $conn->close();
        ?>
    </div>
</body>
</html>
