<?php
session_start();

if (isset($_GET['user_id']) && isset($_GET['user_type'])) {
    $user_id = $_GET['user_id'];
    $user_type = $_GET['user_type'];

    if (isset($_SESSION['username']) && $_SESSION['user_type'] === 'superadmin') {
        $superadmin_username = $_SESSION['username'];
        $conn = new mysqli("localhost", "root", "", "mybusinessdb");

        if ($conn->connect_error) {
            die("Connection failed: " . $conn->connect_error);
        }

        $superadmin_query = "SELECT business_id FROM superadmins WHERE username = '$superadmin_username'";
        $superadmin_result = $conn->query($superadmin_query);

        if ($superadmin_result->num_rows == 1) {
            $superadmin_row = $superadmin_result->fetch_assoc();
            $business_id = $superadmin_row['business_id'];
            if ($user_type === 'buyer') {
                $update_query = "UPDATE buyers SET business_id = $business_id WHERE id = $user_id";
            } elseif ($user_type === 'seller') {
                $update_query = "UPDATE sellers SET business_id = $business_id WHERE id = $user_id";
            } else {
                echo "Invalid user type.";
            }
            if ($conn->query($update_query) === TRUE) {
                echo '<script type="text/javascript">window.location = "view_buyers_sellers.php";</script>';
                exit;
            } else {
                echo "Error adding user to your business" . $conn->error;
            }
        } else {
            echo "Superadmin not found";
        }

        $conn->close();
    } else {
        echo "You are not logged in as a superadmin. Please log in as a superadmin";
    }
} else {
    echo "User ID  not given";
}
?>
