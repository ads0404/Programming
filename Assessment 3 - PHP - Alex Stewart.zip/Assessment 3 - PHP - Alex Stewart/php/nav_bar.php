<!DOCTYPE html>
<html>
<head>
    <style>
        .navbar {
            background-color: #333;
            color: white;
        }

        .navbar a {
            float: left;
            display: block;
            color: white;
            text-align: center;
            padding: 14px 16px;
            text-decoration: none;
        }

        .navbar a:hover {
            background-color: #ddd;
            color: black;
        }

        .navbar .right {
            float: right;
        }
    </style>
</head>
<body>
    <div class="navbar">
        <a href="index.php">Create Business</a>
        <a href="create_buyer_seller.php">Create Buyer/Seller</a>
        <a href="view_buyers_sellers.php">View All Buyers/Sellers</a>
        <a href="account_info.php">Account Information</a>

        <?php
        session_start(); 

        if (isset($_SESSION['username'])) {
            echo '<div class="right"><a href="logout.php">Log out</a></div>';
            if (isset($_SESSION['user_type']) && $_SESSION['user_type'] === 'seller') {
                echo '<a href="add_listing_page.php">Add Product</a>';
                echo '<a href="show_all_listings.php">View My Listings</a>';
            } elseif (isset($_SESSION['user_type']) && $_SESSION['user_type'] === 'buyer') {
                echo '<a href="purchase_item.php">View Market Listings</a>';
            }
        } else {
            echo '<div class="right"><a href="login.php">Login</a></div>';
        }
        ?>
    </div>
</body>
</html>
