<!DOCTYPE html>
<html>
<head>
    <title>Create Buyer/Seller Account</title>
	<link rel="stylesheet" type="text/css" href="stylesheet.css">
</head>
<body>
    <?php include 'nav_bar.php'; ?>
    <h2>Create Buyer/Seller Account</h2>
    <form action="" method="post">
        <label for="account_type">Account Type:</label>
        <select name="account_type">
            <option value="buyer">Buyer</option>
            <option value="seller">Seller</option>
        </select>
        <br><br>
        <label for="username">Username:</label>
        <input type="text" name="username" required>
        <br><br>
        <label for="password">Password:</label>
        <input type="password" name="password" required>
        <br><br>
        <label for="email">Email:</label>
        <input type="email" name="email" required>
        <br><br>
        <label for="fullname">Full Name:</label>
        <input type="text" name="fullname" required>
        <br><br>
        <label for="location">Location:</label>
        <input type="text" name="location" required>
        <br><br>
        <input type="submit" value="Create Account">
    </form>

    <?php
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        $account_type = $_POST['account_type'];
        $username = $_POST['username'];
        $password = $_POST['password'];
        $email = $_POST['email'];
        $fullname = $_POST['fullname'];
        $location = $_POST['location'];
        $conn = new mysqli("localhost", "root", "", "mybusinessdb");

        if ($conn->connect_error) {
            die("Connection failed: " . $conn->connect_error);
        }

        if ($account_type === 'buyer') {
            $sql = "INSERT INTO buyers (username, password, email, fullname, location) 
                    VALUES ('$username', '$password', '$email', '$fullname', '$location')";
        } elseif ($account_type === 'seller') {
            $sql = "INSERT INTO sellers (username, password, email, fullname, location) 
                    VALUES ('$username', '$password', '$email', '$fullname', '$location')";
        }
        if ($conn->query($sql) === TRUE) {
            echo "Account created";
        } else {
            echo "Error: " . $sql . "<br>" . $conn->error;
        }
        $conn->close();
    }
    ?>
</body>
</html>
