<!DOCTYPE html>
<html>
<head>
    <link rel="stylesheet" type="text/css" href="stylesheet.css">
    <style>
        .content-container {
            max-width: 800px;
            margin: 0 auto;
            padding: 20px;
        }

        .listing-item {
            background-color: #f3f3f3;
            padding: 20px;
            margin: 10px;
            border: 1px solid #ccc;
            border-radius: 5px;
        }
    </style>
</head>
<body>
    <?php include 'nav_bar.php'; ?>
    <div class="content-container">
        <h2>Available Listings</h2>
        <?php

        if (isset($_SESSION['username']) && $_SESSION['user_type'] === 'buyer') {
            $buyer_id = $_SESSION['user_id'];
            $conn = new mysqli("localhost", "root", "", "mybusinessdb");

            if ($conn->connect_error) {
                die("Connection failed: " . $conn->connect_error);
            }

            $sql = "SELECT l.listing_name, l.listing_description, l.price
                    FROM listings l
                    JOIN sellers s ON l.seller_id = s.id
                    WHERE s.business_id = (SELECT business_id FROM buyers WHERE id = $buyer_id)";

            $result = $conn->query($sql);

            if ($result->num_rows > 0) {
                while ($row = $result->fetch_assoc()) {
                    echo "<div class='listing-item'>";
                    echo "<h3>" . $row['listing_name'] . "</h3>";
                    echo "<button onclick=\"showListingDetails('listingDetails" . $row['listing_name'] . "')\">View Listing Information</button>";
                    echo "<div id='listingDetails" . $row['listing_name'] . "' style='display: none;'>";
                    echo "<p><strong>Listing Description:</strong> " . $row['listing_description'] . "</p>";
                    echo "<p><strong>Price:</strong> $" . $row['price'] . "</p>";
                    echo "<button>Buy Now</button>";
                    echo "</div>";
                    echo "</div>";
                }
            } else {
                echo "No listings found.";
            }

            $conn->close();
        } else {
            echo "You are not logged in as a buyer. please log in";
        }
        ?>
    </div>

    <script>
        function showListingDetails(id) {
            var details = document.getElementById(id);
            if (details.style.display === "none") {
                details.style.display = "block";
            } else {
                details.style.display = "none";
            }
        }
    </script>
</body>
</html>
