<!DOCTYPE html>
<html>
<head>
    <link rel="stylesheet" type="text/css" href="stylesheet.css">
    <title>Business Home</title>
</head>
<body>
    <?php include 'nav_bar.php'; ?>
    <div class="form-container">
        <h2>Welcome to the Business Home Page</h2>
    </div>
</body>
</html>
