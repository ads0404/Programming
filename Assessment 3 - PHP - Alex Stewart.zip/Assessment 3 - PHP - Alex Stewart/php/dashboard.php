<!DOCTYPE html>
<html>
<head>
    <link rel="stylesheet" type="text/css" href="stylesheet.css">
    <title>Dashboard</title>
    <style>
        .dashboard-container {
            max-width: 800px;
            margin: 0 auto;
            padding: 20px;
        }

        .user-info {
            text-align: right;
            margin-bottom: 10px;
        }
    </style>
</head>
<body>
    <?php include 'nav_bar.php'; ?>
    <div class="dashboard-container">
        <div class="user-info">
            <?php
            session_start();
            if (isset($_SESSION['username'])) {
                echo "Welcome, " . $_SESSION['username'] . " (" . $_SESSION['account_type'] . ")";
            }
            ?>
        </div>
        <h2>Dashboard</h2>
        <?php
        if (isset($_SESSION['account_type'])) {
            switch ($_SESSION['account_type']) {
                case 'business':
                    header('Location: business_home.php');
                    break;
                case 'buyer':
                    header('Location: buyer_home.php');
                    break;
                case 'seller':
                    header('Location: seller_home.php');
                    break;
                case 'superadmin':
                    header('Location: superadmin_home.php');
                    break;
            }
        }
        ?>
    </div>
</body>
</html>