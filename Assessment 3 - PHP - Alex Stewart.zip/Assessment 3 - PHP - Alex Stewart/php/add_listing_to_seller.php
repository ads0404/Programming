<?php
session_start();
if (isset($_SESSION['username']) && $_SESSION['user_type'] === 'seller') {
    if ($_SERVER["REQUEST_METHOD"] === "POST") {

        $seller_id = $_SESSION['seller_id'];


        $listing_name = $_POST['listing_name'];
        $listing_description = $_POST['listing_description'];
        $listing_price = $_POST['listing_price'];

        $listing_date = date("Y-m-d H:i:s");

        $conn = new mysqli("localhost", "root", "", "mybusinessdb");
        if ($conn->connect_error) {
            die("Connection failed: " . $conn->connect_error);
        }
        $sql = "INSERT INTO listings (seller_id, listing_name, listing_description, price, listing_date) VALUES ('$seller_id', '$listing_name', '$listing_description', '$listing_price', '$listing_date')";

        if ($conn->query($sql) === TRUE) {
            header('Location: seller_home.php');
            exit;
        } else {
            echo "Error adding listing: " . $conn->error;
        }
        $conn->close();
    } else {
    }
} else {
    echo "You are not logged in as a seller.";
}
?>