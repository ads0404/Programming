<!DOCTYPE html>
<html>
<head>
    <link rel="stylesheet" type="text/css" href="stylesheet.css">
</head>
<body>
    <?php include 'nav_bar.php'; ?>
    <div class="content-container">
        <h2>My Listings</h2>
        <?php
        
        if (isset($_SESSION['username']) && $_SESSION['user_type'] === 'seller') {
            $seller_id = $_SESSION['seller_id']; 
            
            $conn = new mysqli("localhost", "root", "", "mybusinessdb");
            if ($conn->connect_error) {
                die("Connection failed: " . $conn->connect_error);
            }
            
            $sql = "SELECT * FROM listings WHERE seller_id = '$seller_id'";
            $result = $conn->query($sql);
            
            if ($result->num_rows > 0) {
                echo "<ul>";
                while ($row = $result->fetch_assoc()) {
                    echo "<li>";
                    echo "Listing Name: " . $row['listing_name'] . "<br>";
                    echo "Listing Description: " . $row['listing_description'] . "<br>";
                    echo "Price: $" . $row['price'] . "<br>";
                    echo "</li>";
                }
                echo "</ul>";
            } else {
                echo "No listings found.";
            }
            
            $conn->close();
        } else {
            echo "You are not logged in as a seller. Please log in as a seller to view your listings.";
        }
        ?>
    </div>
</body>
</html>
