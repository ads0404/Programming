<!DOCTYPE html>
<html>
<head>
    <link rel="stylesheet" type="text/css" href="stylesheet.css">
    <title>Account Information</title>
</head>
<body>
    <?php include 'nav_bar.php'; ?>
    <div class="form-container">
        <h2>Account Information</h2>
        <?php
        if (isset($_SESSION['username'])) {
            $allowedAccountTypes = ['seller', 'buyer', 'business', 'superadmin'];

            if (isset($_SESSION['user_type']) && in_array($_SESSION['user_type'], $allowedAccountTypes)) {
                $username = $_SESSION['username'];
                $account_type = $_SESSION['user_type'];
                $conn = new mysqli("localhost", "root", "", "mybusinessdb");

                if ($conn->connect_error) {
                    die("Connection failed: " . $conn->connect_error);
                }

                $table_name = $account_type . 's';
                $username_column = "username";
                $sql = "SELECT * FROM $table_name WHERE username = '$username'";
                $result = $conn->query($sql);

                if ($result->num_rows == 1) {
                    $row = $result->fetch_assoc();
                    echo "<p>Account Type: $account_type</p>";
                    echo "<form action='update_profile.php' method='post'>";
                    echo "<p>Username: <input type='text' name='new_username' value='$username'></p>";
                    
                    if ($account_type === 'superadmin') {
                        echo "<h3>Upload Business Logo</h3>";
                        echo "<input type='file' name='new_logo' accept='image/*'>";
                    } 

                    if ($account_type !== 'superadmin' ) {
                        if ($account_type !== 'business') {
                            echo "<p>Full Name: <input type='text' name='new_fullname' value='{$row['fullname']}'></p>";
                            echo "<p>Email: <input type='text' name='new_email' value='{$row['email']}'></p>";
                        }
                    }

                    if ($account_type === 'business') {
                        echo "<p>Business HQ: <input type='text' name='new_hq_location' value='{$row['hq_location']}'></p>";
                        echo "<p>Business Name: <input type='text' name='new_business_name' value='{$row['business_name']}'></p>";
                        echo "<p>Business Details: <textarea name='new_business_details'>{$row['business_details']}</textarea></p>";
                    }

                    echo "<input type='submit' value='Update Information'>";
                    echo "</form>";
                } else {
                    echo "User Not Found";
                }
                $conn->close();
            } else {
                echo "Incorrect Account Type";
            }
        } else {
            echo "Please Login";
        }
        ?>
    </div>
</body>
</html>
