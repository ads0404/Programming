<!DOCTYPE html>
<html>
<head>
    <link rel="stylesheet" type="text/css" href="stylesheet.css">
    <title>Login</title>
</head>
<body>
    <?php include 'nav_bar.php'; ?>
    <div class="form-container">
        <h2>Login</h2>
        <form action="" method="post">
            <label for="username">Username:</label>
            <input type="text" name="username" required>
            <br><br>
            <label for="password">Password:</label>
            <input type="password" name="password" required>
            <br><br>
            <label for="account_type">Account Type:</label>
            <select name="account_type">
                <option value="business">Business</option>
                <option value="buyer">Buyer</option>
                <option value="seller">Seller</option>
                <option value="superadmin">Super Admin</option>
            </select>
            <br><br>
            <input type="submit" value="Login">
        </form>

        <?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    //log in form submission
    $username = $_POST['username'];
    $password = $_POST['password'];
    $account_type = $_POST['account_type'];

    // connect into the database
    $conn = new mysqli("localhost", "root", "", "mybusinessdb");

    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    //check if user and pass is correct, and is also correct account type
    $table_name = "";

    switch ($account_type) {
        case 'business':
            $table_name = "businesses";
            break;
        case 'buyer':
            $table_name = "buyers";
            break;
        case 'seller':
            $table_name = "sellers";
            break;
        case 'superadmin':
            $table_name = "superadmins";
            break;
        default:
            echo "Invalid account type selected.";
            break;
    }

    if (!empty($table_name)) {
        $sql = "SELECT * FROM $table_name WHERE username = '$username' AND password = '$password'";
        $result = $conn->query($sql);

        if ($result->num_rows == 1) {
            $row = $result->fetch_assoc();
            $_SESSION['username'] = $username;
            $_SESSION['user_type'] = $account_type;
            $_SESSION['user_id'] = $row['id'];

            if ($account_type === 'seller') {
                $_SESSION['seller_id'] = $row['id'];
            }

            switch ($account_type) {
                case 'business':
                    header('Location: business_home.php');
                    break;
                case 'buyer':
                    header('Location: buyer_home.php');
                    break;
                case 'seller':
                    header('Location: seller_home.php');
                    break;
                case 'superadmin':
                    header('Location: superadmin_home.php');
                    break;
            }
        } else {
            echo "Login failed. Please check your credentials.";
        }
    }

    $conn->close();
}
?>
    </div>
</body>
</html>