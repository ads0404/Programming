<!DOCTYPE html>
<html>
<head>
    <title>Create Business Account</title>
	<link rel="stylesheet" type="text/css" href="stylesheet.css">
</head>
<body>
    <?php include 'nav_bar.php'; ?>
    <h2>Create Business Account</h2>
    <form action="" method="post">
        <label for="business_name">Business Name:</label>
        <input type="text" name="business_name" required>
        <br><br>
        <label for="hq_location">HQ Location:</label>
        <input type="text" name="hq_location" required>
        <br><br>
        <label for="business_details">Business Details:</label>
        <textarea name="business_details" required></textarea>
        <br><br>
        <label for="username">Username:</label>
        <input type="text" name="username" required>
        <br><br>
        <label for="password">Password:</label>
        <input type="password" name="password" required>
        <br><br>
        <label for="superadmin_username">Super Admin Username:</label>
        <input type="text" name="superadmin_username" required>
        <br><br>
        <label for="superadmin_password">Super Admin Password:</label>
        <input type="password" name="superadmin_password" required>
        <br><br>
        <input type="submit" value="Create Business and Super Admin">
    </form>

    <?php
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        $business_name = $_POST['business_name'];
        $hq_location = $_POST['hq_location'];
        $business_details = $_POST['business_details'];
        $username = $_POST['username'];
        $password = $_POST['password'];
        $superadmin_username = $_POST['superadmin_username'];
        $superadmin_password = $_POST['superadmin_password'];
        $conn = new mysqli("localhost", "root", "", "mybusinessdb");

        if ($conn->connect_error) {
            die("Connection failed: " . $conn->connect_error);
        }

        $sql = "INSERT INTO businesses (business_name, hq_location, business_details, username, password) 
                VALUES ('$business_name', '$hq_location', '$business_details', '$username', '$password')";
        if ($conn->query($sql) === TRUE) {
            $business_id = $conn->insert_id;
            $sql = "INSERT INTO superadmins (business_id, username, password) 
                    VALUES ('$business_id', '$superadmin_username', '$superadmin_password')";
            if ($conn->query($sql) === TRUE) {
                echo "Business and Super Admin acounts created successfully";
            } else {
                echo "Error creating the super admin account " . $conn->error;
            }
        } else {
            echo "Error creating Busines account " . $conn->error;
        }
        $conn->close();
    }
    ?>
</body>
</html>
