class Competitor {
    constructor(id, name, age, gender) {
      this.id = id;
      this.name = name;
      this.age = age;
      this.gender = gender;
    }
  }
  
  export default Competitor;