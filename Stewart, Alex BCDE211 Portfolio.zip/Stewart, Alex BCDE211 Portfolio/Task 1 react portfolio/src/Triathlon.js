import React from 'react';
import Competitor from './Competitor';
import { openDB } from 'idb';

class Triathlon extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      competitors: [], // displaying a liust of competitotrs
      searchQuery: '', // initialise a empty string
      searchResult: null, // initialise
      editId: null, // initialise
      idCounter: 1, // initialise id couner variable for each competitor
      previousCompetitors: [], // initialise alist for reverting an edit on a list of competitors
      averageAge: null, // initialise average age variable so that it can be set to something later
    };
    this.name ='Queenstown Triathlon'; // queenstown triathlon 

    const databasePromise = openDB('my-database', 1, {
      upgrade(db) {
      },
    });

    this.databasePromise = databasePromise;
  }
  async componentDidMount() {
    const db = await this.databasePromise;
    const transaction = db.transaction('your-object-store', 'readonly');
    const objectStore = transaction.objectStore('your-object-store');
  }
  
  // add competitor should add a competitor with default parameters , and also has input validaton. also handles some functionality for restoring a previous list of competitors
  addCompetitor(name = 'Nameless', age = 18, gender = 'Genderless') {
    if (!name || !age || !gender) {
      throw new Error("Invalid input. Name, age, and gender are required.");
    }
  
    const { idCounter } = this.state; 
    const competitor = new Competitor(idCounter, name, age, gender); 
    this.setState((prevState) => ({
      competitors: [...prevState.competitors, competitor],
      idCounter: idCounter + 1, 
    }));
  }
  
  // allows editing of a competitor
  editCompetitor(id) {
    const competitor = this.state.competitors.find((c) => c.id === id);
    this.setState({
      editId: id,
      editData: competitor, // Store the original data
    });
  }

  //reverts the edits made to a competitor
  revertEdit() {
    this.setState((prevState) => {
      const { competitors, previousCompetitors } = prevState;
  
      if (previousCompetitors.length > 0) {
        const lastEditedCompetitor = previousCompetitors[previousCompetitors.length - 1];
  
        const updatedCompetitors = competitors.map((competitor) => {
          if (competitor.id === lastEditedCompetitor.id) {
            return lastEditedCompetitor;
          }
          return competitor;
        });
  
        return {
          competitors: updatedCompetitors,
          previousCompetitors: previousCompetitors.slice(0, -1), 
          editId: null,
          editData: null,
        };
      }
  
      return prevState; 
    });
  }

  //updates the inputs made when editing a competitor
  updateCompetitor(id, name, age, gender) {
    if (!name || !age || !gender) {
      throw new Error("Invalid input. Name, age, and gender are required.");
    }

    this.setState((prevState) => {
      const updatedCompetitors = prevState.competitors.map((competitor) => {
        if (competitor.id === id) {
          return { ...competitor, name, age, gender };
        }
        return competitor;
      });

      return {
        competitors: updatedCompetitors,
        editId: null,
        previousCompetitors: prevState.competitors,
      };
    });
  }

  //deletes a competitor from the list by parsing the ID as a parameter to select a specific competitor
  deleteCompetitor(id) {
    this.setState((prevState) => {
      const updatedCompetitors = prevState.competitors.filter(
        (competitor) => competitor.id !== id
      );
      return {
        competitors: updatedCompetitors,
      };
    });
  }

  //sorts competitors in ascending order by age
  sortCompetitorsByAge() {
    this.setState((prevState) => ({
      competitors: [...prevState.competitors].sort((a, b) => a.age - b.age),
    }));
  }

  // sorts competitors in alphabetical order from a>z
  sortCompetitorsByName() {
    this.setState((prevState) => ({
      competitors: [...prevState.competitors].sort((a, b) =>
        a.name.localeCompare(b.name)
      ),
    }));
  }

  //handles what the user inputs as a search query in the input box, in order to match a result from the competitor list.
  handleSearch(event) {
    const query = event.target.value;
    this.setState({
      searchQuery: query,
      searchResult: null,
    });
  }

  //saves data to local storage
  componentDidUpdate() {
    const competitors = this.state.competitors;
    localStorage.setItem('competitors', JSON.stringify(competitors));
  }

  //uploads the data from the local storage onto the page.
  componentDidMount() {
    const storedCompetitors = localStorage.getItem('competitors');
    if (storedCompetitors) {
      this.setState({
        competitors: JSON.parse(storedCompetitors),
      });
    }
  }

  //calculates the average age of all competitors inside of the list.
  calculateAverageAge() {
    const competitors = this.state.competitors;
    const totalAge = competitors.reduce((sum, competitor) => sum + competitor.age, 0);
    const averageAge = competitors.length > 0 ? totalAge / competitors.length : 0;
    this.setState({ averageAge: averageAge.toFixed(2) });
  }

  //handles the search logic for what the user inputs and what is inside of the competitor list.
  searchCompetitor() {
    const query = this.state.searchQuery.toLowerCase();
    const competitors = this.state.competitors;
    const searchResult = competitors.filter(
      (competitor) =>
        competitor.name.toLowerCase().includes(query) ||
        competitor.age.toString().includes(query) ||
        competitor.gender.toLowerCase().includes(query)
    );
    this.setState({
      searchResult: searchResult.length > 0 ? searchResult : [],
    });
  }
  //rendering the templates which allows for react responsiveness and functionality.
  render() {
    return (
      <div>
        <h1>Triathlon Competitors</h1>

        <h2>{this.name}</h2>

        <p>Total Competitors: {this.state.competitors.length}</p>
        <h2>Add Competitor</h2>
<form
  onSubmit={(event) => {
    event.preventDefault();
    const name = event.target.elements.name.value || 'Nameless';
    const age = parseInt(event.target.elements.age.value) || 18;
    const gender = event.target.elements.gender.value || 'Genderless';
    this.addCompetitor(name, age, gender);
    event.target.reset();
  }}
>
  <label>
    Name:
    <input type="text" name="name" required defaultValue="Nameless" />
  </label>
  <br />
  <label>
    Age:
    <input type="number" name="age" required min="1" defaultValue={18} />
  </label>
  <br />
  <label>
    Gender:
    <input type="text" name="gender" required defaultValue="Genderless" />
  </label>
  <br />
  <button type="submit">Add Competitor</button>
</form>
		
        <h2>Delete Competitor:</h2>
<form
  onSubmit={(event) => {
    event.preventDefault();
    const id = parseInt(event.target.elements.id.value);
    this.deleteCompetitor(id);
    event.target.reset();
  }}
>
  <label>
    Competitor ID:
    <input type="number" name="id" required />
  </label>
  <br />
  <button type="submit">Delete Competitor</button>
</form>
		
        <h2>Sort Competitors:</h2>
        <button onClick={() => this.sortCompetitorsByAge()}>Sort by Age</button>
        <button onClick={() => this.sortCompetitorsByName()}>Sort by Name</button>

        <h2>Competitor List:</h2>
<ul>
  {this.state.competitors.map((competitor) => (
    <li key={competitor.id}>
      ID: {competitor.id}, Name: {competitor.name}, Age: {competitor.age}, Gender: {competitor.gender}
    </li>
  ))}
</ul>

<h2>Search Competitor:</h2>
<input
  type="text"
  placeholder="Search by name, age, or gender"
  value={this.state.searchQuery}
  onChange={(event) => this.handleSearch(event)}
/>
<button onClick={() => this.searchCompetitor()}>Search</button>

<h2>Search Result:</h2>
{this.state.searchResult !== null ? (
  <ul>
    {this.state.searchResult.length > 0 ? (
      this.state.searchResult.map((competitor) => (
        <li key={competitor.id}>
          ID: {competitor.id}, Name: {competitor.name}, Age: {competitor.age}, Gender: {competitor.gender}
        </li>
      ))
    ) : (
      <li>No matching competitors found.</li>
    )}
  </ul>
) : (
  <p>Perform a search to see the result.</p>
)}
<h2>Edit Competitor:</h2>
<form
  onSubmit={(event) => {
    event.preventDefault();
    const id = parseInt(event.target.elements.id.value);
    const name = event.target.elements.name.value;
    const age = parseInt(event.target.elements.age.value);
    const gender = event.target.elements.gender.value;
    this.updateCompetitor(id, name, age, gender); // Pass the ID and other values to the updateCompetitor function
    event.target.reset();
  }}
>
  <label>
    Competitor ID:
    <input type="number" name="id" required />
  </label>
  <br />
  <label>
    Name:
    <input type="text" name="name" required />
  </label>
  <br />
  <label>
    Age:
    <input type="number" name="age" required />
  </label>
  <br />
  <label>
    Gender:
    <input type="text" name="gender" required />
  </label>
  <br />
  <button type="submit">Update Competitor</button>
</form>
<h2>Revert Competitor Edit:</h2>
      <form
        onSubmit={(event) => {
          event.preventDefault();
          this.revertEdit(); // Call the revertEdit function to revert the last edit
        }}
      >
        <button type="submit">Revert Last Edit</button>
      </form>
      <h2>Calculate Average Age:</h2>
        <form
          onSubmit={(event) => {
            event.preventDefault();
            this.calculateAverageAge();
          }}
        >
          <button type="submit">Calculate Average Age</button>
          {this.state.averageAge !== null ? (
            <p>Average Age: {this.state.averageAge}</p>
          ) : null}
        </form>


      </div>
    );
  }
}

const container = document.getElementById('root');
ReactDOM.render(<Triathlon />, container);
export default Triathlon;