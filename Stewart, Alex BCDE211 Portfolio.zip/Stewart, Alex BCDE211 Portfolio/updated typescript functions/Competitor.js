class Competitor {
  name: string;
  age: number;
  gender: string;
  startTime: number | null;
  finishTime: number | null;

  constructor(
    name: string = 'Unnamed Competitor',
    age: number = 18,
    gender: string = 'Gender not Assigned'
  ) {
    this.name = name;
    this.age = age;
    this.gender = gender;
    this.startTime = null;
    this.finishTime = null;
  }
}

export default Competitor;